cShareSystems.load_pas("Yaez' Maps", [
	"coui://ui/mods/yaez/systems/2P_alfox_refuge.pas",	
]);